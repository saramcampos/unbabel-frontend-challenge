type TranscriptDto = {
    id?: string,
    voice: string,
    text: string,
    errorMessage?: string
}

export type { TranscriptDto }