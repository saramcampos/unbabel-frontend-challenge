import type { TranscriptDto } from '@/dtos/TranscriptDto'
import { defineStore } from 'pinia'
import { getItems, postItem } from '@/api/Client'
import { sanitizeToJson } from '@/utils/sanitizeHelper'

export const useTranscriptStore = defineStore('transcript', {
    state: () => {
        return {
          transcriptsList: [] as Array<TranscriptDto>
        } 
    },
    actions: {
      async fetchTranscript() {
        try {
          const response = await getItems(import.meta.env.VITE_APP_TRANSCRIPTIONS_API_URL, false)
          if (!response?.length) return
          const sanitizedResponse = sanitizeToJson(response)
          this.transcriptsList = JSON.parse(sanitizedResponse)
        } catch (error) {
          console.error('Something went wrong while retrieving transcript', error)
        }
      },
      async postTranscript() {
        this.transcriptsList.forEach(transcript => {
          this.validateTranscripts(transcript)
        })

        // Check if there are new rows to add
        let transcriptToPost = this.transcriptsList.find(transcript => !transcript.id && !transcript.errorMessage)
        if(!transcriptToPost) return

        try {
          const response = await postItem(import.meta.env.VITE_APP_TRANSCRIPTIONS_API_URL, transcriptToPost,false)
          if (!response?.length) return
          const sanitizedResponse = sanitizeToJson(response)
          this.transcriptsList = JSON.parse(sanitizedResponse)
        } catch (error) {
          console.error('Something went wrong while posting transcripts', error)
        }
      },
      removeTranscript(index: number) {
        this.transcriptsList.splice(index, 1)
      },
      addTranscript() {
        const emptyRow = {
          voice: '', 
          text: ''
        }
        this.transcriptsList.push(emptyRow)
      },
      validateTranscripts(transcript: TranscriptDto) {
        debugger
        if (!transcript.voice) {
            transcript.errorMessage = 'Voice is required'
        } else {
            transcript.errorMessage = ''
        }

        if (!transcript.text) {
            transcript.errorMessage = 'Text is required'
        } else {
            transcript.errorMessage = ''
        }
      }
    }
})